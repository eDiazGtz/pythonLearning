from django.apps import AppConfig


class ValidatedredirectappConfig(AppConfig):
    name = 'validatedRedirectApp'
