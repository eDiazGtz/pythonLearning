from django.apps import AppConfig


class ValidatedappConfig(AppConfig):
    name = 'validatedApp'
