from django.apps import AppConfig


class NinjagoldappConfig(AppConfig):
    name = 'NinjaGoldApp'
